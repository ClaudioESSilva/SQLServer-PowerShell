﻿Function Remove-LoginFromInstanceAndDatabases {
    <#
.Synopsis
   Find and drop User and Login from instance
.DESCRIPTION
   Will drop all users and logins asked from a list of instances
.PARAMETER InstanceList
   List of servers to search
.PARAMETER LoginList
   List of logins to search on the instance
.PARAMETER GenerateScript
   If true will drop the users and logins when find it.
   default value is $false. This way a script will be generated and you can analyze it
.EXAMPLE
   Remove-LoginFromInstanceAndDatabases -instanceList 'Localhost' -LoginList 'TestUser'

   Will generate a script to connect to the "localhost" instance and remove "TestUser" user and login from it
.EXAMPLE
   Remove-LoginFromInstanceAndDatabases -instanceList 'Localhost' -LoginList 'TestUser' -GenerateScript False

   Instead of generate a script, will be dropped on the fly
#>

    # cmdletbinding - Let you access to the common CMDLET parameters
    # SupportsShouldProcess - Needed when want to leverage on -WhatIf parameter
    # ConfirmImpact - Take advantage of -Confirm parameter
    [cmdletbinding(SupportsShouldProcess, ConfirmImpact = 'medium')]
    Param (
        # Here you can say what parameters accept input by pipeline among other options (Mandatory, Alias, ValidationSet, ValidateScript, ParameterSetName, etc)
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias('Server', 'cn')]
        [string[]]$InstanceList,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
        [string[]]$LoginList,

        [Parameter(Mandatory = $false)]
        [switch]$GenerateScript
    )

    begin {
        #Set Error and Warnin action
        #$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Continue
        #$WarningPreference = [System.Management.Automation.ActionPreference]::Continue

        #You can set the WhatIf and Confirm Prefence
        #$WhatIfPreference = $true
        #$ConfirmPreference = "medium"

        #Usefull when using the -Verbose common parameter
        Write-Verbose "Loading Microsoft.SqlServer.SMO Assembly"

        #Load assembly, also look for Add-Type (from v3.0 and up)
        [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | Out-Null

        [string[]]$outputScript = $null

        $StartTime = Get-Date
    }
    process {
        # Use each instance within InstanceList
        foreach ($inst in $InstanceList) {

            # here is where the connection is made and $s will be our SQL Server instance
            $s = New-Object "microsoft.sqlserver.management.SMO.Server" $inst
            Write-Verbose "Connecting to '$inst'"

            #reset $logins variable
            $logins = $null
            $databasePG = 0

            # Find server logins where name in login list.
            $logins = $s.logins | Where-Object name -in $LoginList
            Write-Verbose "Search for logins '$LoginList'"

            if ($GenerateScript) {
                # Write data to console
                $outputScript += ":connect $inst";
            }

            if ($logins.Count -gt 0) {
                # Filter offline databases
                foreach ($db in ($s.Databases | Where-Object IsAccessible -eq $true)) {
                    # control variable for progress bar
                    $databasePG++

                    # Update and shows progress bar
                    Write-Progress  -Activity "Scanning databases on '$inst' instance..." -Status "Scanned: $databasePG of $($s.Databases.Count)" -PercentComplete (($databasePG / $s.Databases.Count) * 100) -CurrentOperation "$db"

                    Write-Verbose "Search for users '$LoginList' on database '$db'"

                    # find users within databases which login match the login list.
                    $users = $db.users | Where-Object {$_.login -in $LoginList}

                    if ($users.Count -gt 0) {
                        Write-Verbose "Users found on '$db'"
                        if ($GenerateScript) {
                            $outputScript += "use $db"
                        }

                        $users | ForEach-Object {
                            if ($GenerateScript) {
                                $outputScript += "drop user $_;"
                            }
                            else {
                                # Alows to compose the question for the -WhatIf / -Confirm common parameter
                                if ($PSCmdlet.ShouldProcess("User '$($_.Name)' will be dropped from '$($db.Name)' database.",
                                    "This action will drop the user '$($_.Name)' from '$($db.Name)' database.`nDo you wish to continue?",
                                    "Drop user")) {
                                    #This will drop the user on the fly
                                    $_.drop();
                                    Write-Verbose "User '$($_.Name)' dropped!"
                                }
                                # User choose "No" for the question or when using with -WhatIf also go to this code
                                else {
                                    Write-Warning "-Confirm = false - User will remain @ '$($db.Name)' database"
                                }
                            }
                        }

                        if ($GenerateScript) {
                            $outputScript += "go"
                        }
                    }
                    else {
                        Write-Verbose "No users found on '$($db.Name)'"
                    }
                }

                #Remove child progress bar (a way to refresh)
                Write-Progress -Id 2 -Activity "..." -Status "..." -Completed -ParentId 1

                if ($GenerateScript) {
                    $outputScript += "use master"
                }

                $logins | ForEach-Object {
                    if ($GenerateScript) {
                        $outputScript += "drop login $_;"
                    }
                    else {
                        if ($PSCmdlet.ShouldProcess("Login '$_' will be dropped from '$inst' instance",
                        "This action will drop the user '$_'`nDo you wish to continue?", "Drop user")) {
                            $_.drop();
                        }
                        else {
                            Write-Warning "-Confirm = false - Login will remain @ '$inst' instance"
                        }
                    }
                }

                if ($GenerateScript) {
                    $outputScript += "go`r`n";
                }
            }
            else {
                Write-Verbose "No logins found on '$inst'"
            }
        }
    }
    end {
        Write-Output $outputScript
        # Write the elapsed time running this script.
        Write-Output "Elapsed time: $($(Get-Date) - $StartTime)"
    }
}

#Get-Help Remove-LoginFromInstanceAndDatabases -Detailed
Remove-LoginFromInstanceAndDatabases -InstanceList '.' -LoginList 'TestUser' -GenerateScript -Verbose

Remove-LoginFromInstanceAndDatabases -InstanceList '.' -LoginList 'TestUser'  -Verbose

Remove-LoginFromInstanceAndDatabases -InstanceList '.' -LoginList 'TestUser' -Confirm

Remove-LoginFromInstanceAndDatabases -InstanceList '.' -LoginList 'TestUser' -Confirm

Remove-LoginFromInstanceAndDatabases

#'localhost' | Remove-LoginFromInstanceAndDatabases -LoginList 'TestUser', 'TestUser2' -WhatIf -Verbose
'TestUser' | Remove-LoginFromInstanceAndDatabases -InstanceList 'Localhost' -WhatIf
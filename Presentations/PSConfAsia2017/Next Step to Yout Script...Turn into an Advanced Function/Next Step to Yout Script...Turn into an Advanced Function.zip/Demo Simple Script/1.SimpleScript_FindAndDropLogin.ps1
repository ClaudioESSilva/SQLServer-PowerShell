﻿[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | Out-Null

[string[]]$instanceList = 'localhost'#, 'VM'
[string[]]$loginList = 'TestUser', 'TestUser2'
[switch]$GenerateScript = $false

foreach ($srv in $instanceList) {

    $s = New-Object "microsoft.sqlserver.management.SMO.Server" $srv

    $logins = $s.logins | Where-Object { $_.name -in $loginList }

    if ($GenerateScript) {
        ":connect $srv"
    }

    if ($logins.Count -gt 0) {
        # Filter offline databases
        foreach ($db in $s.Databases | Where-Object {$_.IsAccessible -eq $true}) {
            $users = $db.users | Where-Object {$_.login -in $loginList}

            if ($users.Count -gt 0) {
                if ($GenerateScript) {
                    "use $db"
                }

                $users | ForEach-Object {
                    if ($GenerateScript) {
                        "drop user $_;"
                    }
                    else {
                        $_.drop()
                    }
                }

                if ($GenerateScript) {
                    "go"
                }
            }
        }

        if ($GenerateScript) {
            "use master"
        }

        $logins | ForEach-Object {
            if ($GenerateScript) {
                "drop login $_;"
            }
            else {
                $_.drop()
            }
        }

        if ($GenerateScript) {
            "go"
            ""
        }
    }
}
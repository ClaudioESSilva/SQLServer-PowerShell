return "No no no..don't run the whole script :-)"
#How get the module
#Install-Module ReportingServicesTools

#Import-Module ReportingServicesTools -Force

#View command
Get-Module -Name ReportingServicesTools

#View available Functions
Get-Command -Module ReportingServicesTools -CommandType Function

#Report server URL parameter
$reportServerUri = 'http://localhost:8080/ReportServer'
$RSItemsFolder = 'D:\temp\SSRS Items'
$RSItemsFolderWDS = 'D:\temp\SSRS Items\WithDataSource'
$downloadFolder = 'D:\temp\Demo Download'
$EncryptionKeyPath = "D:\temp\"
$user = "domain\user"

# Backup Encryption key
Invoke-Item $EncryptionKeyPath

Backup-RsEncryptionKey -ReportServerInstance "SSRS" -ReportServerVersion SQLServer2017 -Password "strongPa55w0rd" -KeyPath "$EncryptionKeyPath\EncryptionKey_bck.snk"


# Creates a new folder on the root of report server
New-RsFolder -ReportServerUri $reportServerUri -RsFolder "/" -FolderName "Singapore"

New-RsFolder -ReportServerUri $reportServerUri -RsFolder "/" -FolderName "Portugal"

# Grant Browser access to user psconfasiauser (one at a time)
Grant-RsCatalogItemRole -ReportServerUri $reportServerUri -Path "/Singapore" -RoleName 'Browser' -Identity $user

# BUG on v0.0.2.9 - Can't add a second role
Grant-RsCatalogItemRole -ReportServerUri $reportServerUri -Path "/Singapore" -RoleName 'Content Manager' -Identity $user

Grant-RsCatalogItemRole -ReportServerUri $reportServerUri -Path "/Singapore" -RoleName 'My Reports' -Identity $user
Grant-RsCatalogItemRole -ReportServerUri $reportServerUri -Path "/Singapore" -RoleName 'Publisher' -Identity $user
Grant-RsCatalogItemRole -ReportServerUri $reportServerUri -Path "/Singapore" -RoleName 'Report Builder' -Identity $user

# Wrong RoleName - Will fail
Grant-RsCatalogItemRole -ReportServerUri $reportServerUri -Path "/Singapore" -RoleName 'Publisher2' -Identity $user

# See list of accesses
Get-RsCatalogItemRole -ReportServerUri $reportServerUri -Path "/Singapore"

# Revoke access to user domain\user (will remove ALL roles)
Get-help Revoke-RsCatalogItemAccess -Detailed
#Revoke-RsCatalogItemAccess -ReportServerUri $reportServerUri -Path "/Singapore" -Identity $user

#Add example to Revoke and Grant all (-1) accesses
[System.Collections.ArrayList]$ActualRoles = (Get-RsCatalogItemRole -ReportServerUri $reportServerUri -Path "/Singapore" | Where-Object Identity -eq $user).Roles | Select-Object -ExpandProperty Name

$ActualRoles

$ActualRoles.Remove("Report Builder")
$ActualRoles.Remove("Publisher")

$ActualRoles

Revoke-RsCatalogItemAccess -ReportServerUri $reportServerUri -Path "/Singapore" -Identity $user

# Add each one
$ActualRoles | ForEach-Object {
    Grant-RsCatalogItemRole -ReportServerUri $reportServerUri -Path "/Singapore" -RoleName "$_" -Identity $user
}




## Reports
# Upload a single Report
Write-RsCatalogItem -ReportServerUri $reportServerUri -Path "$RSItemsFolder\performance_dashboard_main.rdl" -RsFolder "/Singapore"

# View existing reports inside folder
Get-RsCatalogItems -ReportServerUri $reportServerUri -RsFolder "/Singapore"


# Upload an entire folder
# If the rdl already exists it will give error and stop execution
Invoke-Item $RSItemsFolder

Write-RsFolderContent -ReportServerUri $reportServerUri -Path $RSItemsFolder -RsFolder "/Singapore"

# For now to solve this, we can get all existing rdl from
foreach ($rdl in (Get-ChildItem -Path $RSItemsFolder -Filter *.rdl)) {
    Write-RsCatalogItem -ReportServerUri $reportServerUri -Path $rdl.FullName -RsFolder "/Singapore" -Overwrite
}

# Download one item
Invoke-Item $downloadFolder
Out-RsCatalogItem -ReportServerUri $reportServerUri -Destination $downloadFolder -RsItem "/Singapore/performance_dashboard_main"


# Download all folder content
Out-RsFolderContent -ReportServerUri $reportServerUri -Destination $downloadFolder -RsFolder "/Singapore"

# Working with non-built-in data sources
# Create new Data Source
$newRSDSName = "Datasource"
$newRSDSExtension = "SQL"
$newRSDSConnectionString = "Initial Catalog=msdb; Data Source=localhost"
$newRSDSCredentialRetrieval = "Store"
$newRSDSCredential = Get-Credential -Message "Enter user credentials for data source" -UserName psconfasiaUser

New-RsDataSource -ReportServerUri $reportServerUri -RsFolder "/Portugal" -Name $newRSDSName -Extension $newRSDSExtension `
                 -ConnectionString $newRSDSConnectionString -CredentialRetrieval $newRSDSCredentialRetrieval -DatasourceCredentials $newRSDSCredential

# Upload Instances.rdl report
Write-RsCatalogItem -ReportServerUri $reportServerUri -Path "$RSItemsFolderWDS\Instances.rdl" -RsFolder "/Portugal"

## Subscriptions
# Only works if the report already have/had an DataSource (not working with Custom Data Sources)
$dataSource = Get-RsItemReference -ReportServerUri $reportServerUri -Path "/Portugal/Instances"
Set-RsDataSourceReference -ReportServerUri $reportServerUri -Path "/Portugal/Instances" -DataSourceName $dataSource.Name -DataSourcePath "/Portugal/Datasource"

# Configure email settings (if you have the SSRS configuration manager open you need to re-open it)
Set-RsEmailSettings -ReportServerInstance "SSRS" -SmtpServer "smtp2.localhost" -SenderAddress "help@psconfasia.com" -ReportServerVersion SQLServer2017 -Authentication Ntlm

# Crate new subscription for performance_dashboard_main report (Thanks to Mark Wragg @markwragg)
$newSubs = @()
1..100 | ForEach-Object {
    Write-Output "Creating subscription $_"

    $Schedule = New-RsScheduleXml -Daily -Interval (Get-Random -Minimum 1 -Maximum 5)

    if ($_ % 2 -eq 0) {
        $to = 'test@someaddress.com'
    }
    else {
        #$Schedule = New-RsScheduleXml -Weekly -Interval (Get-Random -Minimum 1 -Maximum 5)
        $to = 'manager@someaddress.com'
    }

    $params = @{
        ReportServerUri = $reportServerUri
        Path = '/Portugal/instances'
        Description = "instances - $_"
        Destination = 'Email'
        Schedule = $Schedule
        Subject = 'instances report'
        To = $to
        RenderFormat = 'PDF'
    }

    $newSubs += New-RsSubscription @params
}

$newSubs | Select-Object

# View Subscriptions
Get-RsSubscription -ReportServerUri $reportServerUri -Path "/Portugal/instances" | Select-Object -First 5


# Grab all subscriptions which email is manager
$managerSubscriptions = Get-RsSubscription -ReportServerUri $reportServerUri -Path "/Portugal/instances" | Where-Object {
         $_.DeliverySettings.Parametervalues.name -eq "to" `
    -and $_.DeliverySettings.Parametervalues.Value -Contains "manager@someaddress.com"
}

# Number of subscriptions to: manager
$managerSubscriptions.Count

$managerSubscriptions | Remove-RsSubscription -ReportServerUri $reportServerUri -Verbose


# Export/Import Subcriptions

# Get specific subscriptions
$subscriptionsToDownload = Get-RsSubscription -ReportServerUri $reportServerUri -Path "/Portugal/instances" | Select-Object -First 5

# Export to individual files
Invoke-Item "$downloadFolder\Subscriptions"
$subscriptionsToDownload | ForEach-Object {Export-RsSubscriptionXml -Subscription $_ -Path "$downloadFolder\Subscriptions\$($_.SubscriptionId).xml"}

# Export all subscriptions to just one file
$subscriptionsToDownload | Export-RsSubscriptionXml -Path "$downloadFolder\Subscriptions\AllSubscriptions.xml"

# Get all subscriptions pipe to remove
Get-RsSubscription -ReportServerUri $reportServerUri -Path "/Portugal/instances" | Remove-RsSubscription -ReportServerUri $reportServerUri -Verbose

# Import subscritpion file and set to a report
Import-RsSubscriptionXml -ReportServerUri $reportServerUri "$downloadFolder\Subscriptions\AllSubscriptions.xml" | Set-RsSubscription -ReportServerUri $reportServerUri -Path "/Portugal/instances"

# Import various subscription files
Get-ChildItem -Path "$downloadFolder\Subscriptions\*.xml" | ForEach-Object {
    Import-RsSubscriptionXml -ReportServerUri $reportServerUri $_.FullName | Set-RsSubscription -ReportServerUri $reportServerUri -Path "/Portugal/instances"
}

